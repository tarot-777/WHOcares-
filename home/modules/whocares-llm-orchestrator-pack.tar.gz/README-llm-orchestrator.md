# WHOcares! LLM Orchestrator module

Drop-in module for `home/modules/llm-orchestrator.nix`.

It adds practical non-coder LLM orchestration commands:

- `why` / `skills` — searchable command registry.
- `ctx` — capture repo, Nix, git, system, and selected file context.
- `ctx --copy --open chatgpt` — copy context and open ChatGPT.
- `llm-copy` — pipe stdin/files/directories into a clipboard-ready prompt.
- `llm-open gemini FILE` — copy prompt and open Gemini.
- `runlog COMMAND ...` — run a command, save transcript, create debug prompt.
- `nix-fixpack` / `hm-doctor` — build Nix/Home Manager diagnostic pack.
- `llm-review` — package current git diff for LLM review.
- `llm-patch` / `aipatch` — apply AI patch safely on a new git branch and run checks.
- `lastlog` / `lastask` — Zsh functions for previous-command automation.

## Install from this pack

```sh
bash apply-llm-orchestrator.sh "$HOME/WHOcares!"
cd "$HOME/WHOcares!"
nix flake check --no-build --show-trace
nh home build . -c malachi@coffin
nh home switch . -c malachi@coffin
```

## Manual install

```sh
cp home/modules/llm-orchestrator.nix "$HOME/WHOcares!/home/modules/llm-orchestrator.nix"
```

Then add to `home/malachi/default.nix` imports:

```nix
../modules/llm-orchestrator.nix
```

And enable it under `whycare`:

```nix
llmOrchestrator = {
  enable = true;
  browser = "firefox";
  maxFileBytes = 50000;
  maxFilesBrief = 35;
  maxFilesFull = 90;
};
```

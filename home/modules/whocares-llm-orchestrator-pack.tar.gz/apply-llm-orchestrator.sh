#!/usr/bin/env bash
set -euo pipefail

repo="${1:-$HOME/WHOcares!}"
pack_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "$repo/flake.nix" ]]; then
  echo "No flake.nix found at: $repo" >&2
  echo "Usage: bash apply-llm-orchestrator.sh /path/to/WHOcares!" >&2
  exit 2
fi

mkdir -p "$repo/home/modules" "$repo/home/malachi"
cp "$pack_dir/home/modules/llm-orchestrator.nix" "$repo/home/modules/llm-orchestrator.nix"

python3 - "$repo/home/malachi/default.nix" "$repo/README.md" <<'PY'
from pathlib import Path
import sys

default_path = Path(sys.argv[1])
readme_path = Path(sys.argv[2])

s = default_path.read_text()
if '../modules/llm-orchestrator.nix' not in s:
    s = s.replace('    ../modules/shell.nix\n', '    ../modules/shell.nix\n    ../modules/llm-orchestrator.nix\n')
if 'llmOrchestrator = {' not in s:
    s = s.replace(
        '    externalRepos.enable = true;\n\n    profiles = {',
        '    externalRepos.enable = true;\n\n'
        '    llmOrchestrator = {\n'
        '      enable = true;\n'
        '      browser = "firefox";\n'
        '      maxFileBytes = 50000;\n'
        '      maxFilesBrief = 35;\n'
        '      maxFilesFull = 90;\n'
        '    };\n\n'
        '    profiles = {'
    )
default_path.write_text(s)

if readme_path.exists():
    r = readme_path.read_text()
    section = """
## LLM Orchestrator

`home/modules/llm-orchestrator.nix` adds self-documenting automation for
working as a non-coding LLM orchestrator. It captures enough machine and
repository context to paste into ChatGPT, Gemini, Claude, or another assistant
without manually reconstructing what happened.

| Command | Action |
|---|---|
| `why [term]` / `skills [term]` | Search the local command registry and explain what a tool does |
| `ctx` | Print a redacted Markdown context bundle for the current repo |
| `ctx --copy --open chatgpt` | Copy context to the clipboard and open ChatGPT |
| `llm-copy` | Copy stdin, files, or directory context as an LLM-ready prompt |
| `llm-open gemini FILE` | Copy a prompt and open Gemini, ChatGPT, Claude, Perplexity, or Copilot |
| `runlog COMMAND ...` | Run any command, save the transcript, and copy a debug prompt |
| `hm-doctor` / `nix-fixpack` | Build a full Home Manager/Nix diagnostic bundle with logs |
| `llm-review` | Package current git changes for model review |
| `llm-patch` / `aipatch` | Apply an AI-generated patch on a new git branch and run checks |
| `lastlog` / `lastask` | Zsh helpers for rerunning or explaining the previous command |

Good daily flow:

```sh
ctx --copy --open chatgpt
runlog hm-check
nix-fixpack --open gemini
llm-review --open chatgpt
llm-patch --clipboard
```

"""
    if '## LLM Orchestrator' not in r:
        r = r.replace('## Neovim\n', section + '## Neovim\n')
        readme_path.write_text(r)
PY

cd "$repo"
if command -v alejandra >/dev/null 2>&1; then
  alejandra home/modules/llm-orchestrator.nix home/malachi/default.nix README.md
fi

echo "Added llm-orchestrator.nix and enabled whycare.llmOrchestrator."
echo "Next checks:"
echo "  nix flake check --no-build --show-trace"
echo "  nh home build . -c malachi@coffin"
echo "  nh home switch . -c malachi@coffin"
